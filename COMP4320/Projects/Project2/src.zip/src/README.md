To run the programs, first compile the server and client,
run the server first and then the client with the networks
ip ad a command line argument. Program uses
stop and wait protocol and Waittime is set to 5 seconds
on the server side if a product is dropped.

Example script was tested with a drop probability of .5 and 
a damage probability of .5.