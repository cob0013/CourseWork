#ifndef __unp_h
#define __unp_h
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <time.h> 
#include <netdb.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <sstream>
#define SERV_PORT 8080
#define MAXLINE 4096
#define BUFFSIZE 512
using namespace std;
#endif