The code used to generate the plots included in this folder can be found in
assignment5.py. The plots themselves are saved in the results directory.


3bIII. For the plot of lambda vs the performance, the performance gets better as 
lambda increases, until it reacehs optimal performance at lambda = .6. It then 
begins to worse again as lambda increases


3bIV. For the plot of mu vs performance, the performance starts off the best
with mu = 100, and then peformance gets worse as mu increases.