//Carson Barnett
//Quiz1
//Prints hello world
//no help

#include <iostream>
using namespace std;

int main() 
{
    cout << "Hello, World!";
    cout << endl;
    return 0;
}
